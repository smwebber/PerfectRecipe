package src.recipe;

public class Measurement {
    private static double TSP_TO_ML = 4.92892;
    private static double TBSP_TO_ML = 14.7868;
    private static double FLOZ_TO_ML = 29.5735;
    private static double CUP_TO_ML = 240;
    private static double QT_TO_ML = 946.353;
    private static double GAL_TO_L = 3.785;
    private static double LB_TO_G = 453.592;
    private static double OZ_TO_G = 28.3495;

    
    public static String getOtherUnit(String unit, double amount){
        String otherUnit;
        switch(unit){
        case "pound":
            otherUnit = "gram";
            break;
        case "gram":
            if(amount >= LB_TO_G) otherUnit = "pound";
            else otherUnit = "ounce";
            break;
        case "gallon":
            otherUnit = "liter";
            break;
        case "quart":
            otherUnit = "liter";
            break;
        case "cup":
            otherUnit = "milliliter";
            break;
        case "teaspoon":
            otherUnit = "milliliter";
            break;
        case "tablespoon":
            otherUnit = "milliliter";
            break;
        case "fluid ounce":
            otherUnit = "milliliter";
            break;
        case "ounce":
            otherUnit = "gram";
            break;
        case "milliliter":
            otherUnit = "teaspoon";
            if(amount > GAL_TO_L * 1000) otherUnit = "gallon";
            if(amount > QT_TO_ML && amount <= GAL_TO_L * 1000) otherUnit = "quart";
            if(amount > CUP_TO_ML && amount <= QT_TO_ML) otherUnit = "cup";
            if(amount > FLOZ_TO_ML && amount <= CUP_TO_ML) otherUnit = "fluid ounce";
            if(amount > TBSP_TO_ML && amount <= FLOZ_TO_ML) otherUnit = "tablespoon";
            break;
        case "Celsius":
            otherUnit = "Fahrenheit";
            break;
        case "Fahrenheit":
            otherUnit = "Celsius";
            break;
        default: 
            otherUnit = unit; //allowing for null units in the case of quantities of items or when the unit is nonstandard such as 'clove' or 'pinch'
            break;
        }
        return otherUnit;
    }
    
    public static double convert(String unit, String newUnit, double amount){
        switch(unit){
        case "pound":
            amount *= LB_TO_G;
            break;
        case "ounce":
            amount *= OZ_TO_G;
            break;
        case "gram":
            if(amount >= OZ_TO_G / 2) amount *= 1 / LB_TO_G;
            else amount *= 1 / OZ_TO_G;
            break;
        case "gallon":
            amount *= GAL_TO_L;
            break;
        case "quart":
            amount *= QT_TO_ML / 1000;
            break;
        case "cup":
            amount *= CUP_TO_ML;
            break;
        case "teaspoon":
            amount *= TSP_TO_ML;
            break;
        case "tablespoon":
            amount *= TBSP_TO_ML;
            break;
        case "fluid ounce":
            amount *= FLOZ_TO_ML;
            break;
        case "Celsius":
            amount = amount * 1.8 + 32;
            break;
        case "Fahrenheit":
            amount = (amount - 32) / 1.8;
            break;
        case "milliliter": 
            switch(newUnit){
            case "gallon":
                amount *= 1 / GAL_TO_L / 1000;
                break;
            case "quart":
                amount *= 1 / QT_TO_ML / 100;
                break;
            case "cup":
                amount *= 1 / CUP_TO_ML;
                break;
            case "fluid ounce":
                amount *= 1 / FLOZ_TO_ML;
                break;
            case "teaspoon":
                amount *= 1 / TSP_TO_ML;
                break;
            case "tablespoon":
                amount *= 1 / TBSP_TO_ML;
                break;
            default:
                break;
            }
        default:
            break;
        }
        return amount;
    }
    
}
