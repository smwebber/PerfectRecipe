package src.recipe;

import java.util.ArrayList;
import java.util.HashMap;
//import src.timer.GlobalTimer;

public class Recipe {
    private String name;
    private ArrayList<Step> steps;
    private HashMap<Ingredient, Quantity> ingredients;
    private ArrayList<Equipment> equipment;
    private ArrayList<String> cuisineType;  //to assist in searching, can be null
    private double servings;
    private int difficulty; //can be null
    private int cookTime; 
    private String imgURL; //can be null
    
    public Recipe(String name, ArrayList<Step> steps/*ArrayList<Instruction> instructions*/, HashMap<Ingredient, Quantity> ingredients, ArrayList<Equipment> equipment, ArrayList<String> cuisineType, double servings, int difficulty, int cookTime, String imgURL){
        this.name = name;
        this.steps = steps;
        //this.instructions = instructions;
        this.ingredients = ingredients;
        this.equipment = equipment;
        this.cuisineType = cuisineType;
        this.servings = servings;
        this.difficulty = difficulty;
        this.cookTime = cookTime;
        this.imgURL = imgURL;
    }
    
    //called by RecipeDatabase after user specifies number of servings
    public Recipe(Recipe recipe, double servings){
        recipe.adjustRecipe(servings);
    }
    
    /*
     * 
     */
    public void adjustRecipe(double servings){
        for(Ingredient ing : ingredients.keySet()){
            //access ingredients' Quantity object
            Quantity q = ingredients.get(ing);
            double amount = q.getAmount();
            q.setAmount(amount * (servings / this.servings));
            //adjust the Quantity to the appropriate unit
            
            //put() the Quantity back into ingredients HashMap
            ingredients.put(ing, q);
        }   
    }
    
    public void adjustRecipe(boolean changeMeasurementSystem){
        for(Ingredient ing : ingredients.keySet()){
            Quantity q = ingredients.get(ing);
            if(changeMeasurementSystem){
                q.adjust();
            }
            ingredients.put(ing, q);
        }
    }
    
    /* Starts off GlobalTimer
     * GlobalTimer uses steps to create StepTimers
     * Step, StepTimer, and GlobalTimer handle the remainder of this process
     */
 /*
  public void cook(){
  GlobalTimer gt = new GlobalTimer(cookTime, steps);
  gt.start();
  }
  */

    public String getName(){
        return this.name;
    }
    
    public ArrayList<Step> getSteps(){
        return this.steps;
    }
    
    /*public ArrayList<Instruction> getInstructions(){
        return this.instructions;
    }*/
    
    public ArrayList<Equipment> getEquipment(){
        return this.equipment;
    }
    
    public HashMap<Ingredient, Quantity> getIngredient(){
        return this.ingredients;
    }
    
    public ArrayList<String> getCuisineType(){
        try{
            return this.cuisineType;
        }
        catch(NullPointerException ex){
            ArrayList<String> cuisine = new ArrayList<>();
            cuisine.add("Cuisine not found");
            return cuisine;
        }
    }
    
    public double getServings(){
        try{
            return this.servings;
        }
        catch(NullPointerException ex){
            return 1;
        }
    }
    
    public void setServings(double servings){
        this.servings = servings;
    }
    
    public int getDifficulty(){
        return this.difficulty;
    }
    
    public int getCookTime(){
        return this.cookTime;
    }
    
    public String getImgURL(){
        return this.imgURL;
    }
    
    public String toString(){
        String recipe = name + "\n";
        for(Ingredient i: ingredients.keySet()){
            recipe += String.format("%s: %s\n", ingredients.get(i).toString(), i.toString());
        }
        return recipe;
    }


    public ArrayList<Ingredient> getIngredientList() {
        ArrayList<Ingredient> ingredientList = new ArrayList<>();
        for(Ingredient i : ingredients.keySet()){
            ingredientList.add(i);
        }
        return ingredientList;
    }
}