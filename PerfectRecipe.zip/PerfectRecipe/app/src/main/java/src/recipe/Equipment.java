package src.recipe;

import java.util.ArrayList;

public class Equipment {
	private String name;
	private ArrayList<String> subs; //will not be used in this prototype
	
	public Equipment(String name, ArrayList<String> subs){
		this.name = name;
		this.subs = subs;
	}
	
	public String getName(){
		return this.name;
	}
	
	/*This method changes the name variable of Equipment by,
	 * 1. checking that the substitution to be made is valid
	 * 2. changing the name if it is valid
	 * 3. informing the user in the case that it is invalid
	 */
	public void substitute(String name){
		boolean found = false;
		for(int i = 0; i < subs.size(); i++){
			if(subs.get(i).equals(name)){
				this.name = name;
				found = true;
				break;
			}
		}
		if(!found){
			System.out.printf("%s is an invalid substitution for %s\n", name, this.name);
		}
	}
	
	public ArrayList<String> getSubs(){
		return this.subs;
	}
	
	public void addSubstitute(String name){
		boolean found = false;
		for(int i = 0; i < subs.size(); i++){
			if(subs.get(i).equals(name)){
				found = true;
				break;
			}
		}
		if(!found){
			subs.add(name);
		}
		else System.out.printf("%s is already in substitute list\n", name);
	}
	
	public String toString(){
		return this.name;
	}
}
