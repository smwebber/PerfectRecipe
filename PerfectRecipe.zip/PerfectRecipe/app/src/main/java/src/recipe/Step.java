package src.recipe;

public class Step implements Comparable<Step>{
    private double startTime;
    private double duration;
    private double endTime;
    private String instruction;
    private String imgURL;
    private boolean type;

    
    public Step(double startTime, double duration, double endTime, String instruction, boolean type, String imgURL){
        this.startTime = startTime;
        this.duration = duration;
        this.endTime = endTime;
        this.instruction = instruction;
        this.type = type;
        this.imgURL = imgURL;
    }
    
    public double getStartTime(){
        return this.startTime;
    }
    
    public double getDuration(){
        return this.duration;
    }
    
    public double getEndTime(){
        return this.endTime;
    }
    
    public String getInstruction(){
        return this.instruction;
    }
    
    public boolean getType(){
        return this.type;
    }
    
    public String getImgURL(){
        return this.imgURL;
    }
    
    public String toString(){
        return instruction;
    }
    
    public int compareTo(Step other){
        if(other.getStartTime() > this.getStartTime()){
            return 1;
        }
        if(other.getStartTime() < this.getStartTime()){
            return -1;
        }
        return 0;
    }
    
}
