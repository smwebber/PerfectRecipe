package src.recipe;

import java.util.ArrayList;

public class Ingredient {
	private String name;
	private ArrayList<String> subs;
	private ArrayList<String> foodGroup;
	
	public Ingredient(String name, ArrayList<String> subs, ArrayList<String> foodGroup){
		this.name = name;
		this.subs = subs;
		this.foodGroup = foodGroup;
	}
	
	public String getName(){
		return this.name;
	}
	
	/*this method searches the list of possible substitutions, checks
	 *its validity as a substitute, and renames Ingredient for displaying 
	 *it in Instruction
	 */
	public void substitute(String name){
		boolean found = false;
		for(int i = 0; i < subs.size(); i++){
			if(subs.get(i).equals(name)){
				this.name = name;
				found = true;
				break;
			}
		}
		if(!found){
			System.out.printf("%s is an invalid substitution for %s\n", name, this.name);
		}
	}
	
	public void addSubstitute(String name){
		boolean found = false;
		for(int i = 0; i < subs.size(); i++){
			if(subs.get(i).equals(name)){
				found = true;
				break;
			}
		}
		if(!found){
			subs.add(name);
		}
		else System.out.printf("%s is already in substitute list\n", name);
	}
	
	public ArrayList<String> getFoodGroups(){
		return this.foodGroup;
	}
	
	public void addFoodGroup(String group){
		boolean found = false;
		for(int i = 0; i < foodGroup.size(); i++){
			if(foodGroup.get(i).equals(group)){
				found = true;
				break;
			}
		}
		if(!found){
			this.foodGroup.add(group);
		}
		else System.out.printf("%s is already in substitute list\n", name);
	}
		
	
	public ArrayList<String> getSubs(){
		return this.subs;
	}
	
	public String toString(){
		return name;
	}
}
