package src.recipe;

public class Quantity {
	private double amount;
	private String unit;
	
	public Quantity(double amount, String unit){
		this.amount = amount;
		this.unit = unit;
	}
	
	public double getAmount(){
		return this.amount;
	}
	
	public void setAmount(double amount){
		this.amount = amount;
	}
	
	public String getUnit(){
		return this.unit;
	}
	
	public void adjust(){
		String newUnit = Measurement.getOtherUnit(unit, amount);
		double newAmount = Measurement.convert(unit, newUnit, amount);
		this.unit = newUnit;
		this.amount = newAmount;
	}
	
	public String toString(){
		return String.format("%4.2f %s", amount, unit);
	}

}
