/**
 * Resource classes for Duke/Coursera course.
 */
package src.duke;
