package src.filter;

import android.os.Build;
import android.support.annotation.RequiresApi;

import src.recipe.Recipe;
import java.util.Objects;

public class KeywordFilter implements Filter {
    private String keyword;

    public KeywordFilter(String key)
    { keyword = key; }



    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean satisfies(Recipe x) {
            for (String match : x.getName().split(" ")) {
                if (match.contains(keyword))
                    return true;
            }
        return false;
    }
}
