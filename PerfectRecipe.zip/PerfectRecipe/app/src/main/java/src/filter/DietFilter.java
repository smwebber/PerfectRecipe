package src.filter;


import src.recipe.Ingredient;
import src.recipe.Recipe;

import java.util.ArrayList;

public class DietFilter implements Filter{
    private String foodGroup;

    public DietFilter (String group)
    {foodGroup = group; }

    @Override
    public boolean satisfies (Recipe x) {
        boolean temp = false;
        ArrayList<Ingredient> match = x.getIngredientList();
        for (String no: match.getFoodGroups())
            temp = match.getFoodGroups().contains(foodGroup) ? true: false;
        return temp;
    }
}
