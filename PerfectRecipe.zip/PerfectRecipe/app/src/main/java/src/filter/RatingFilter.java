package src.filter;

import src.recipe.Recipe;

public class RatingFilter implements Filter {
    private Double minRating;
    private Double maxRating;


    public RatingFilter(double rating, boolean check)
    {
        //if check is true, min time is defined
        // if check is false, then max time is defined
        if (check)
            minRating = rating;
        else
            maxRating = rating;

    }

    public RatingFilter(double min, double max){
        minRating = min;
        maxRating = max;
    }

    @Override
    public boolean satisfies(Recipe x) {
        if (minRating == null) return x.getRating() <= maxRating;
        if (maxRating == null) return x.getRating() >= minRating;

        return x.getRating() >= minRating && x.getRating() <= maxRating;
    }
}
