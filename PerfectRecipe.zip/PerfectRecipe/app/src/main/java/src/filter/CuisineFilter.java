package src.filter;

import src.recipe.Recipe;

public class CuisineFilter implements Filter {
    private String cuisines;
    public CuisineFilter (String cuisine){
        cuisines = cuisine;
    }


    @Override
    public boolean satisfies (Recipe x) {
        boolean temp = false;
        for (String no: x.getCuisineType())
            temp = x.getCuisineType().contains(cuisines) ? true: false;
        return temp;
    }
}
