package src.filter;


import src.recipe.Ingredient;
import src.recipe.Recipe;

import java.util.ArrayList;
import java.util.Collections;

public class IngredientFilter implements Filter {
    private ArrayList<Ingredient> ingredientsIncluded;
    private ArrayList<Ingredient> ingredientsExcluded;

    public IngredientFilter (ArrayList<Ingredient> included, ArrayList<Ingredient> excluded)
    {
        ingredientsIncluded = included;
        ingredientsExcluded = excluded;
    }

    @Override
    public boolean satisfies(Recipe x) {
        ArrayList<Ingredient> match = x.getIngredientList();
        return Collections.disjoint(match, ingredientsExcluded) && match.containsAll(ingredientsIncluded);

    }
}
