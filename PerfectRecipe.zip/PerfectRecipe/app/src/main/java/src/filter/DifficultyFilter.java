package src.filter;

import src.recipe.Recipe;


public class DifficultyFilter implements Filter {
    private byte difficulty = 0;

    public DifficultyFilter (byte difficult)
    { difficulty = difficult; }

    @Override
    public boolean satisfies(Recipe x) {
        return x.getDifficulty() == difficulty;
    }
}
