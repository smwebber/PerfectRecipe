package src.filter;
import src.recipe.Recipe;

import java.util.ArrayList;

public interface Filter {
    boolean satisfies(Recipe x);


}
