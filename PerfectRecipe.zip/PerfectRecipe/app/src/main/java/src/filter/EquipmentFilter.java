package src.filter;


import src.recipe.Equipment;
import src.recipe.Recipe;

import java.util.ArrayList;
import java.util.Collections;

public class EquipmentFilter implements Filter {
    private ArrayList<Equipment> equipmentIncluded;
    private ArrayList<Equipment> equipmentExcluded;

    public EquipmentFilter (ArrayList<Equipment> included, ArrayList<Equipment> excluded)
    {
        equipmentIncluded = included;
        equipmentExcluded = excluded;
    }

    @Override
    public boolean satisfies(Recipe x) {
        ArrayList<Equipment> match = x.getEquipment();
        return Collections.disjoint(match, equipmentExcluded) && match.containsAll(equipmentIncluded);

    }
}
