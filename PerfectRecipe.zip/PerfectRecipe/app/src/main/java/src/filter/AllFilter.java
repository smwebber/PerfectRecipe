package src.filter;


import src.recipe.Recipe;

import java.util.ArrayList;

public class AllFilter implements Filter {
    private ArrayList<Filter> filters;
    public AllFilter(ArrayList<Filter> filter)
    { filters = filter; }

    @Override
    public boolean satisfies(Recipe x) {
        boolean sat = true;
        for (int i = 0; i < filters.size(); i++) {
            Filter f = filters.get(i);
            if (!f.satisfies(x))
            sat = false;
        }
        return sat;
    }
}
