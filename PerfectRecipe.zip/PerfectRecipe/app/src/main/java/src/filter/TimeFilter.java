package src.filter;

import src.recipe.Recipe;


public class TimeFilter implements Filter {
    private Integer minTime;
    private Integer maxTime;


    public TimeFilter(int time, boolean check)
    {
        //if check is true, min time is defined
        // if check is false, then max time is defined
        if (check)
            minTime = time;
        else
            maxTime = time;

    }

    public TimeFilter(int min, int max){
        minTime = min;
        maxTime = max;
    }

    @Override
    public boolean satisfies(Recipe x) {
        if (minTime == null) return x.getCookTime() <= maxTime;
        if (maxTime == null) return x.getCookTime() >= minTime;

        return x.getCookTime() >= minTime && x.getCookTime() <= maxTime;
    }
}
