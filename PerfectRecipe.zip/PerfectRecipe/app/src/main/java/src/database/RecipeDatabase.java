package src.database;

import src.duke.*;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;

import src.recipe.Equipment;
import src.recipe.Ingredient;
import src.recipe.Quantity;
import src.recipe.Recipe;
import src.recipe.Step;

public class RecipeDatabase {
    private static HashMap<Integer, Recipe> ourRecipes;
    
    private static void initialize() throws FileNotFoundException{
        if(ourRecipes == null){
            ourRecipes = new HashMap<>();
            addRecipes("data/recipes/RecipeList.csv");
        }
    }
    
    public static void initialize(String filename) throws FileNotFoundException{
        if(ourRecipes == null){
            ourRecipes = new HashMap<>();
            addRecipes("data/recipes/" + filename);
        }
    }
    
    private static void addRecipes(String filename) throws FileNotFoundException{
        initialize();
        FileResource fr = new FileResource(filename);
        CSVParser csvp = fr.getCSVParser();
        String stepsLocation = "";
        String ingrLocation = "";
        String equipLocation = "";
        String cuisineLocation = "";
        
        //get String and primitive values for Recipe
        for(CSVRecord rec : csvp){
            int recipeID = 0; //used at the end to .put() constructed Recipe in HashMap
            String name = rec.get("name");
            stepsLocation = rec.get("steps");
            ingrLocation = rec.get("ingredients");
            equipLocation = rec.get("equipment");
            cuisineLocation = rec.get("cuisine_type");
            double servings = Integer.parseInt(rec.get("servings"));
            int difficulty = Integer.parseInt(rec.get("difficulty"));
            int cookTime = Integer.parseInt(rec.get("cook_time"));
            String imgURL = rec.get("img_url");
            
                  
            //get Steps
            ArrayList<Step> steps = new ArrayList<>();
            
            FileResource frStep = new FileResource(stepsLocation);
            CSVParser stepParser = frStep.getCSVParser();
            
            for(CSVRecord recStep : stepParser){
                double startTime = Double.parseDouble(recStep.get("start_time"));
                double duration = Double.parseDouble(recStep.get("duration"));
                double endTime = Double.parseDouble(recStep.get("end_time"));
                String instruction = recStep.get("instruction");
                boolean type = Boolean.parseBoolean(recStep.get("type"));
                String imgStepURL = recStep.get("img_url");
                steps.add(new Step(startTime, duration, endTime, instruction, type, imgStepURL));
                System.out.println(steps.get(0));
            }
            
            //get Ingredients
            HashMap<Ingredient, Quantity> ingredients = new HashMap<>();
            FileResource frIngr = new FileResource(ingrLocation);
            CSVParser ingrParser = frIngr.getCSVParser();
            
            for(CSVRecord recIngr : ingrParser){
                String ingredient = recIngr.get("ingredient");
                /*
                 * the following two variables are used to construct Quantity 
                 * which is taken together with Ingredient to construct the HashMap
                 */
                String amount = recIngr.get("amount");
                String unit = recIngr.get("unit");
                Quantity q = new Quantity(Double.parseDouble(amount), unit);
                /*
                 * the following two variables will be constructed based 
                 * on the path names found in the CSV field
                 */
                ArrayList<String> subs = new ArrayList<>(); //incomplete
                ArrayList<String> foodGroup = new ArrayList<>();
                Ingredient i = new Ingredient(ingredient, subs, foodGroup);
                ingredients.put(i, q);
            }
            
            //get Equipment
            ArrayList<Equipment> equipment = new ArrayList<>();
            FileResource frEquip = new FileResource(equipLocation);
            CSVParser equipParser = frEquip.getCSVParser();
            
            for(CSVRecord recEquip : equipParser){
                String equipName = recEquip.get("name");
                ArrayList<String> subs = new ArrayList<>();
                equipment.add(new Equipment(equipName, subs));
            }
            
            //get cuisineType
            ArrayList<String> cuisineType = new ArrayList<>();
            FileResource frCuisine = new FileResource(cuisineLocation);
            CSVParser cuisineParser = frCuisine.getCSVParser();
            
            for(CSVRecord recCuisine : cuisineParser){
                cuisineType.add(recCuisine.get("type"));
            }
            ourRecipes.put(recipeID, new Recipe(name, steps, ingredients, equipment, cuisineType, servings, difficulty, cookTime, imgURL));
        }
        
    }
    
    public static Recipe sendRecipe(int recipeID, double servings){
        return new Recipe(ourRecipes.get(recipeID), servings);
    }
    
    public static Recipe getRecipe(int recipeID){
        return ourRecipes.get(recipeID);
    }
}