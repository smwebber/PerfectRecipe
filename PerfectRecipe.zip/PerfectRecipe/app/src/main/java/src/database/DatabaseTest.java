package src.database;


/**
 * Write a description of DatabaseTest here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import src.recipe.*;
import java.io.FileNotFoundException;
import java.lang.NullPointerException;

public class DatabaseTest {
   public void test(){
       try{ 
            RecipeDatabase.initialize("RecipeList.csv");
            Recipe r = RecipeDatabase.getRecipe(0);
            System.out.println("Original\n" + r);
            r.adjustRecipe(2.0);
            System.out.println("Two servings\n" + r);
            r.adjustRecipe(true);
            System.out.println("Two servings, converted\n" + r);
            r.adjustRecipe(4.0);
            System.out.println("Four servings, converted\n" + r);
            r.adjustRecipe(true);
            System.out.println("Original\n" + r);
       }
       catch(FileNotFoundException e){
           //RecipeDatabase.initialize();
           System.out.println("file not found");
       }
       catch(NullPointerException e){
           System.out.println("null pointer");
       } 
   }
    
}
