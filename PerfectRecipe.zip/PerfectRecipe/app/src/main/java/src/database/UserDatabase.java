package src.database;
import org.apache.commons.csv.*;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.FileNotFoundException;

/**
 * Write a description of UserDatabase here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class UserDatabase {
    /*private static HashMap<String, UserProfile> ourUsers;

    private static void initialize() throws FileNotFoundException{
        if(ourUsers == null){
            ourUsers = new HashMap<>();
            addUsers("data/users/Users.csv");
        }
    }

    public static void initialize(String filename) throws FileNotFoundException{
        if(ourUsers == null){
            ourUsers = new HashMap<>();
            addUsers("data/users/" + filename);
        }
    }

    private static void addUsers(String filename) throws FileNotFoundException{
        initialize();
        FileResource fr = new FileResource(filename);
        CSVParser csvp = fr.getCSVParser();
        String historyLocation = "";
        String filterLocation = "";
        String savedRecipeLocation = "";
        String equipmentLocation = "";

        for(CSVRecord rec : csvp){
            String username = rec.get("username");
            String password = rec.get("password");
            String email = rec.get("email");
            filterLocation = rec.get("default_filters");
            equipmentLocation = rec.get("equipment");
            savedRecipeLocation = rec.get("saved_recipes");
            historyLocation = rec.get("history");

            //get filters
            FileResource frFilter = new FileResource(filterLoccation);
            CSVParser filterParser = frFilter.getCSVParser();
            for(CSVRecord recFilter : filterParser){
                //TO DO
            }

            //get equipment
            FileResource frEquip = new FileResource(equipmentLocation);
            CSVParser equipParser = frEquip.getCSVParser();
            for(CSVRecord recEquip : equipParser){
                //TO DO
            }

            //get saved recipes
            FileResource frSaved = new FileResource(savedRecipeLocation);
            CSVParser savedParser = frSaved.getCSVParser();
            for(CSVRecord recSaved : savedParser){
                //TO DO
            }

            //get history
            FileResource frHistory = new FileResource(historyLocation);
            CSVParser historyLocation = frHistory.getCSVParser();
            for(CSVRecord recHistory: historyParser){
                //TO DO
            }
        }
    }


    //Called by UserProfile
    public static void updateUser(String username){
        //TO DO
        //writes to CSV file and updates user information in HashMap
    }*/
}
